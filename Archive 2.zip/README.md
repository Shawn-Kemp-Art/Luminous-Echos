# fxhash_Template
 
A base fxhash template using paper.js to create generative outputs that can be exported as digital blueprints for cutting with lasers and other plotting tools. 